#include "lib/lmpt.h"
#include <iostream>
#include <thread>
#include <fstream>
#include <string>
#include <sstream>

void handleInput(Lamport* lamport) {
    std::cout << "Available commands: REQUEST, EXIT, STATUS\n";
    std::string input;
    while (true) {
        std::cout << ">";
        std::cin >> input;
        if (input == "REQUEST") {
            lamport->request();
        } else if (input == "EXIT") {
            return;
        } else if (input == "STATUS") {
            lamport->printConfig();
        }
    }
}

int main(int argc, char* argv[]) {
    int port = 0;
    int sys_id = 0;
    std::string filename;

    if (argc != 7) {
        std::cerr << "Usage: " << argv[0] << " -p <PORT NO> -i <SYS ID> -f <CONFIG FILE> \n";
        return 1;
    }

    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if ((arg == "-p") && i + 1 < argc) {
            port = std::stoi(argv[++i]);
        } else if ((arg == "-i") && i + 1 < argc) {
            sys_id = std::stoi(argv[++i]);
        } else if ((arg == "-f") && i + 1 < argc) {
            filename = argv[++i];
        } else {
            std::cerr << "Usage: " << argv[0] << " -p <PORT NO> -i <SYS ID> -f <CONFIG FILE>\n";
            return 1;
        }
    }

    Lamport lamport(sys_id, port, filename);

    std::thread listenerThread(&Lamport::receive, &lamport);
    std::thread queueHandlerThread(&Lamport::handleQueue, &lamport);
    std::thread inputHandlerThread(handleInput, &lamport);

    listenerThread.join();
    queueHandlerThread.join();
    inputHandlerThread.join();

    return 0;
}
