#include "lmpt.h"

Lamport::Lamport(int id, int lport, const std::string& filename) : processId(id), listenPort(lport), logicalClock(0) {
    loadConfig(filename);
}

Lamport::~Lamport() {}

void Lamport::addNode(int id, std::string ip, int port) {
    struct sockaddr_in node;
    node.sin_family = AF_INET;
    node.sin_port = htons(port);
    node.sin_addr.s_addr = inet_addr(ip.c_str());
    nodeList[id] = node;
}

bool Lamport::loadConfig(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open())
        return false;

    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        int id, port;
        if (iss >> port >> id) {
            addNode(id, "127.0.0.1", port);
        }
    }
    return true;
}

int Lamport::unicast(Signal sig, int sysId) {
    struct sockaddr_in node = nodeList[sysId];
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket creation failed");
        return -1;
    }

    if (connect(sock, (struct sockaddr*)&node, sizeof(node)) < 0) {
        perror("Connection failed");
        close(sock);
        return -1;
    }

    SyncData data;
    {
        std::lock_guard<std::mutex> lock(clockMutex);
        data.timestamp = logicalClock++;
    }
    data.senderId = processId;
    data.msgType = sig;

    if (send(sock, &data, sizeof(data), 0) < 0) {
        perror("Send failed");
        close(sock);
        return -1;
    }

    close(sock);
    return 0;
}

int Lamport::broadcast(Signal sig) {
    for (auto& it : nodeList) {
        if (it.first != processId) {
            if (unicast(sig, it.first) < 0)
                return -1;
        }
    }
    return 0;
}

void Lamport::receive() {
    int servsock = socket(AF_INET, SOCK_STREAM, 0);
    if (servsock < 0) {
        perror("Socket creation failed");
        return;
    }

    struct sockaddr_in servAddr;
    servAddr.sin_family = AF_INET;
    servAddr.sin_port = htons(listenPort);
    servAddr.sin_addr.s_addr = INADDR_ANY;

    if (bind(servsock, (struct sockaddr*)&servAddr, sizeof(servAddr)) < 0) {
        perror("Bind failed");
        return;
    }

    SyncData data;
    while (true) {
        listen(servsock, 5);
        int sock = accept(servsock, NULL, NULL);
        if (sock < 0) {
            perror("Accept failed");
            return;
        }

        if (recv(sock, &data, sizeof(data), 0) < 0) {
            perror("Receive failed");
            close(sock);
            return;
        }
        close(sock);
        handleData(data);
    }
}

void Lamport::handleData(SyncData data) {
    std::lock_guard<std::mutex> lock(clockMutex);
    logicalClock = std::max(logicalClock, data.timestamp) + 1;

    switch (data.msgType) {
        case REQUEST:
            std::cout << "Received REQUEST from " << data.senderId << std::endl;
            requestQueue.push({data.timestamp, data.senderId});
            if (requestQueue.top().second != processId)
                unicast(REPLY, data.senderId);
            break;

        case REPLY:
            std::cout << "Received REPLY from " << data.senderId << std::endl;
            replyMap.insert(data.senderId);
            break;

        case RELEASE:
            std::cout << "Received RELEASE from " << data.senderId << std::endl;
            if (data.senderId == requestQueue.top().second)
                requestQueue.pop();
            else {
                std::cerr << "Invalid release" << std::endl;
                exit(1);
            }
            break;
    }
}

void Lamport::handleQueue() {
    while (true) {
        if (!requestQueue.empty()) {
            if (requestQueue.top().second == processId) {
                if (replyMap.size() == nodeList.size() - 1) {
                    {
                        std::lock_guard<std::mutex> lock(clockMutex);
                        logicalClock++;
                    }
                    std::cout << logicalClock << ": Entering Critical Section" << std::endl;
                    std::this_thread::sleep_for(std::chrono::seconds(10));
                    broadcast(RELEASE);
                    replyMap.clear();
                    requestQueue.pop();
                    std::cout << logicalClock << ": Exiting Critical Section" << std::endl;
                }
            }
        }
    }
}

void Lamport::printConfig() {
    std::lock_guard<std::mutex> lock(clockMutex);
    std::cout << "ID: " << processId;
    std::cout << " Port: " << listenPort;
    std::cout << " Clock: " << logicalClock << std::endl;

    std::cout << "Node List: " << std::endl;
    for (auto& it : nodeList) {
        std::cout << "ID: " << it.first << " PORT: " << ntohs(it.second.sin_port) << " HOST: " << inet_ntoa(it.second.sin_addr) << std::endl;
    }

    std::cout << "Request Queue: " << std::endl;
    std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, std::greater<std::pair<int, int>>> temp = requestQueue;
    while (!temp.empty()) {
        std::cout << "ID: " << temp.top().second << " TIMESTAMP: " << temp.top().first << std::endl;
        temp.pop();
    }

    std::cout << std::endl;

    std::cout << "Reply Map: " << std::endl;
    for (auto& it : replyMap) {
        std::cout << "ID: " << it << std::endl;
    }
    std::cout << std::endl;
}

void Lamport::request() {
    {
        std::lock_guard<std::mutex> lock(clockMutex);
        logicalClock++;
    }
    broadcast(REQUEST);
    requestQueue.push({logicalClock, processId});
}
