#ifndef LAMPORT_H
#define LAMPORT_H

#include <thread>
#include <mutex>
#include <map>
#include <string>
#include <queue>
#include <set>
#include <fstream>
#include <sstream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <iostream>

enum Signal {
    REQUEST,
    REPLY,
    RELEASE,
};

class SyncData {
public:
    int timestamp;
    int senderId;
    Signal msgType;
};

class Lamport {
private:
    int processId;
    int logicalClock;
    int listenPort;
    std::mutex clockMutex;
    std::map<int, struct sockaddr_in> nodeList;
    std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, std::greater<std::pair<int, int>>> requestQueue;
    std::set<int> replyMap;

public:
    Lamport(int id, int lport, const std::string& filename);
    ~Lamport();

    void addNode(int id, std::string ip, int port);
    bool loadConfig(const std::string& filename);
    int unicast(Signal sig, int sysId);
    int broadcast(Signal sig);
    void receive();
    void handleData(SyncData data);
    void handleQueue();
    void printConfig();
    void request();
};

#endif
