## Project Structure


.
├── src
│   ├── main.cpp
│   └── lib
│       ├── lmpt.cpp
│       └── lmpt.h
├── Makefile
└── README.md


- *src/main.cpp*: Entry point of the application, handles command-line arguments and initializes the algorithm.
- *src/lib/lmpt.cpp*: Implementation of the Lamport's Mutual Exclusion Algorithm.
- *src/lib/lmpt.h*: Header file containing the class declaration and necessary data structures.
- *Makefile*: Contains rules for building the project.
- *README.md*: This file, providing an overview of the project.

## Building the Project

To build the project, navigate to the project directory and run the following command:


make


This will compile the source files and generate the executable main.

## Running the Project

After building the project, you can run the executable with the following command:


./main -p <PORT_NO> -i <SYSTEM_ID> -f <CONFIG_FILE>


Replace <PORT_NO> with the desired port number for the process to listen on, <SYSTEM_ID> with a unique identifier for the process, and <CONFIG_FILE> with the path to the configuration file containing information about other nodes in the distributed system.

The program will start listening for incoming messages on the specified port and will wait for user input. During execution, the program will prompt you to enter additional commands:

- REQUEST: Send a request for accessing the critical section.
- STATUS: Print the current system configuration.
- EXIT: Terminate the program.

## Team Members

Chitra Thanmai Sai - 20cs01050
Pittala Sivani - 20cs01067
Goram Nikhitha - 20cs01066